<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Hello World</title>
</head>
	<p>HTML says Hello World</p>
    <script type="text/javascript">
		document.write('<p>JavaScript says Hello World</p>');
	</script>
    <?php
		echo "<p>PHP says Hello World</p>";
	?>
<body>
</body>
</html>